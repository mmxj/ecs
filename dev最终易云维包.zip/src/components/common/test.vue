<style scoped>
.testCont{padding: 10px;overflow: hidden;}
.row{float: left;overflow: hidden;margin:5px 5px;text-align: center;}
.row p:first-child{background: #FFF0F0;}
.row p:last-child{background: #F0F0FF;}
</style>
<template>
	<div class="testCont">
		<div class="row">
			<p>The tower, which was not supposed to be there, plunges into the earth in a place just before the black pine forest begins to give way to swamp and then the reeds and wind-gnarled trees of the marsh flats.</p>
			<p>那座直插入地下的塔不该出现在这里，而黑松林恰好由此开始逐渐过渡为沼泽，再往前则是更加泥泞的湿地，杂草丛生，长满了被风吹得歪歪扭扭的树木。</p>
		</div>
		<div class="row">
			<p>Beyond the marsh flats and the natural canals lies the ocean and, a little farther down the coast, a derelict lighthouse.</p>
			<p>湿地和自然水道以远，便是海洋。稍远处的海滩上，还有一座废弃的灯塔。</p>
		</div>
		<div class="row">
			<p>All of this part of the country had been abandoned for decades, for reasons that are not easy to relate.</p>
			<p>国境内的这整片区域已经废弃达数十年，原因很难说清。</p>
		</div>
		
	</div>
</template>

<script>
</script>

