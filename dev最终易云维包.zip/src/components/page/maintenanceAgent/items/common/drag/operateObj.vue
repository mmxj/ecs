<template>
	<div id="">
		
	</div>
</template>

<script>
	export default{
		data(){
			return{
				
			}
		},
		props:['basicObjPropsData'],
		mounted(){
			
		}
	}
</script>

<style scoped="scoped">
	
</style>