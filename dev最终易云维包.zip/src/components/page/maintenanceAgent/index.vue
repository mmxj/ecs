<style scoped lang='scss'>
.el_mainContent {
  height: 100%;
  position: relative;
  background-color: #fff;
  & .btmCont {
    position: absolute;
    bottom: 0;
    z-index: 1;
  }
  & .topInfo_content {
    background: #FFF;
    padding: 0;
    overflow: hidden;
    position: absolute;
    top: 0;
    z-index: 2;
    border-bottom: 1px solid #DADDE0;
  }
  & .topUnitWrap{border-right: 2px solid #fff;}
}

.topInfoWrap {
  border: 2px solid #EAF4F3;
  overflow: hidden;
}



.el_content {
  width: 100%;
  overflow: hidden;
}

.hostWrap {
  width: 100%;
}

.hostCont {
  min-width: 880px;
  max-width: 1200px;
  margin: 50px auto 20px;
  & .hostTxt {
    text-align: center;
    color: #1F2D3D;
    font-size: 20px;
    font-weight: bold;
    margin-top: 25px;
  }
}

.imgWrap {
  width: 880px;
  height: 300px;
  margin: 0 auto;
  background-size: cover;
  & img {
    cursor: pointer;
    margin: 0 auto;
    display: block;
  }
}

.hostData {
  margin: 50px auto 0;
  min-width: 880px;
  max-width: 1200px;
  border-left: 2px solid #E0EDEC;
  border-right: 2px solid #E0EDEC;
  height: 110px
}

.hostDataCon {
  cursor: pointer;
  width: 100px;
  height: 110px;
  margin: 0 auto;
  & p {
    text-align: center;
  }
  & p:nth-child(2) {
    color: #1F2D3D;
    font-size: 30px;
    font-weight: bold;
    line-height: 42px
  }
  & p.warn {
    color: #E84F3F
  }
}

.gutterBd {
  border-right: 2px solid #E0EDEC;
}

.hostDataImg {
  margin: 0 auto;
  display: block;
}


/* .wbWrap {
  width: 100%;
  overflow: hidden;
  padding: 20px 15px;
  background: #fff;
}

.wbR {
  float: right;
  width: 420px;
  min-height: 80vh;
  max-height: 100vh;
  overflow: auto;
  padding-left: 15px;
  border-left: 2px solid #E9F2F1;
  & .noDataImg {
    width: 220px;
    display: block;
    margin: 150px auto 25px
  }
  & .noData p {
    font-size: 16px;
    font-weight: bold;
    color: #1ABC9C;
    text-align: center;
  }
} */


/* .wbTop {
  width: 100%;
  height: 50px;
  line-height: 50px;
  padding-left: 45px;
  font-weight: bold;
  font-size: 16px;
  color: #1F2D3D
}

.wbL {
  margin-right: 420px;
  overflow: hidden;
  padding-right: 20px;
}

.wbRUnit {
  cursor: pointer;
  padding-top: 20px;
  padding-bottom: 15px;
  border-bottom: 2px solid #E8F1F1;
  overflow: hidden;
}

.wbRImg {
  width: 108px;
  height: 72px;
  border: 1px solid #E1EEED;
  float: left;
}

.wbRCont {
  float: left;
  overflow: hidden;
  & p {
    padding-left: 15px;
    max-width: 270px;
    overflow: hidden;
  }
  & p:first-child span {
    font-weight: 700;
    color: #1F2D3D;
    font-size: 16px;
    padding-left: 10px;
    margin-bottom: 10px;
  }
}

.wbRdesc {
  width: 100%;
  overflow-x: hidden;
  padding-top: 10px;
  color: #212F3F;
  font-weight: bold;
  max-height: 50px;
  overflow-y: auto;
}

.wbLBg {
  max-width: 850px;
  margin: 145px auto 20px;
  height: 260px;
  & .wbLNum {
    cursor: pointer;
    width: 308px;
    height: 258px;
    border-bottom: 2px solid #E5F0EF;
    margin: 0 auto;
    padding-top: 50px;
    & p {
      text-align: center;
      font-size: 30px;
    }
    & p:first-child {
      font-size: 140px;
      color: #E74C3C;
      font-weight: bold;
      position: relative;
      line-height: 140px;
    }
    & p:first-child img {
      position: absolute;
      top: -50px;
      right: 30px;
    }
  }
} */


/* p.eqNumTxt {
  cursor: pointer;
  text-align: center;
  font-size: 30px;
  & span {
    color: #1F2D3D;
    padding-left: 30px;
    padding-right: 30px;
    font-size: 40px;
    line-height: 40px;
    position: relative;
    top: 5px;
  }
} */

</style>
<template>
  <div class="el_mainContent" v-loading='loading_yz'>
    <div class="el_content topInfo_content">
      <topInfo v-for='n in 5' :type='n' :propsData='eqData[n]' :goTo='goTo'></topInfo>
    </div>
    <div class="el_content btmCont">
      <div class="clearfix"></div>
      <div class="hostWrap">
        <div class="hostCont">
          <div class="imgWrap" :style='imgWrapStyle'>
            <img :src="hostPngSrc" height="300" width="300" alt="" @click="goTo('yz_equipments_manage',{'EquipmentTypeId':eqData[0].EquipmentTypeId})" />
          </div>
          <p class="hostTxt">{{eqData[0].TypeName}}</p>
          <el-row class="hostData" :gutter="2">
            <el-col :span="8" class='gutterBd'>
              <div class="hostDataCon" @click="goTo('yz_equipments_manage',{'EquipmentTypeId':eqData[0].EquipmentTypeId})">
                <img :src="TotalPngSrc" class='hostDataImg' />
                <p>{{eqData[0].TotalNum}}</p>
                <p>总设备数</p>
              </div>
            </el-col>
            <el-col :span="8" class='gutterBd'>
              <div class="hostDataCon" @click="goTo('yz_equipments_manage',{'EquipmentTypeId':eqData[0].EquipmentTypeId,'AlarmStatus':4})">
                <img :src="AlarmPngSrc" class='hostDataImg' />
                <p class='warn'>{{eqData[0].AlarmNum}}</p>
                <p>告警设备数</p>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="hostDataCon" @click="goTo('yz_equipments_manage',{'EquipmentTypeId':eqData[0].EquipmentTypeId,'OnlineStatus':'0'})">
                <img :src="OffLinePngSrc" class='hostDataImg' />
                <p>{{eqData[0].OffLineNum}}</p>
                <p>离线设备数</p>
              </div>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
    <!-- 维保商 -->
    <!-- <div v-if='EntitySort==1'>
      <div class="wbWrap">
        <div class="wbR">
          <div class="wbTop" :style='wbRTopSty'>告警消息</div>
          <div v-if='AlarmList.length==0' class='noData'>
            <img :src="noDataPngSrc" class="noDataImg" />
            <p>恭喜您，没有告警消息</p>
            <p>设备一切正常</p>
          </div>
          <div v-else>
            <div class="wbRUnit" v-for='item in AlarmList' @click='linkToWarn'>
              <img v-lazy="item.EquipmentPhotos" alt="" class="wbRImg" />
              <div class="wbRCont">
                <p><img :src="item.AlarmLevel==1?AlarmLevel1PngSrc:item.AlarmLevel==2?AlarmLevel2PngSrc:AlarmLevel3PngSrc" alt="" /><span>{{item.EquipmentName}}</span></p>
                <p>所属项目：{{item.ProjectName}}</p>
                <p>告警事件：{{item.AlarmDateTime}}</p>
              </div>
              <div class="wbRdesc">告警内容：{{item.AlarmContent}}</div>
            </div>
          </div>
        </div>
        <div class="wbL">
          <div class="wbTop" :style='wbLTopSty'>设备统计</div>
          <div class="wbLBg" :style='AlarmList.length==0?noAlarmBgSty:hasAlarmBgSty'>
            <div class="wbLNum" @click='linkTo(4)'>
              <p>{{AlarmList.length==0?0:AlarmNum}}<img :src="AlarmPngSrc" /></p>
              <p>告警设备数</p>
            </div>
          </div>
          <p class='eqNumTxt' @click='linkTo()'>当前设备总数<span>{{EquipmentNum}}</span>台</p>
        </div>
      </div>
    </div> -->
  </div>
</template>
<script>
// import { mapMutations } from 'vuex'
/*import noAlarmBgSrc from 'assets/images/index/8.png'
import hasAlarmBgSrc from 'assets/images/index/9.png'
import noDataPngSrc from 'assets/images/index/noData.png'
import AlarmLevel1PngSrc from 'assets/images/index/12.png'
import AlarmLevel2PngSrc from 'assets/images/index/11.png'
import AlarmLevel3PngSrc from 'assets/images/index/10.png'
import wbLTopPngSrc from 'assets/images/index/8-1.png'
import wbRTopPngSrc from 'assets/images/index/8-1.png'*/
import hostPngSrc from 'assets/images/index/7.png'
import hostBgSrc from 'assets/images/index/7_1.png'
import TotalPngSrc from 'assets/images/index/1.png'
import OffLinePngSrc from 'assets/images/index/3.png'
import AlarmPngSrc from 'assets/images/index/2.png'
import indexCircle from 'components/common/indexCircle'
import topInfo from 'components/common/topInfo'
import * as Common from 'src/assets/js/common';
const URL = Common.Const.url
const FUNC = Common.Func
const AXIOS = FUNC.axios
const GET = AXIOS.get
export default {
  data: function() {
    return {
      routerNameWarn: 'warning_lists',
      loading_yz: true,
      urlName: '_equipments_manage',
      urlType: '',
      //维保商首页数据
      /*noAlarmBgSty: {
        backgroundSize: 'cover',
        background: `url(${noAlarmBgSrc}) no-repeat`,
      },
      hasAlarmBgSty: {
        backgroundSize: 'cover',
        background: `url(${hasAlarmBgSrc}) no-repeat`,
      },
      hasAlarmBgSrc,
      noDataPngSrc,
      AlarmLevel1PngSrc,
      AlarmLevel2PngSrc,
      AlarmLevel3PngSrc,
      wbRTopSty: {
        background: `#DFECEB url(${wbRTopPngSrc}) 14px 15px no-repeat`
      },
      wbLTopSty: {
        background: `#DFECEB url(${wbLTopPngSrc}) 14px 15px no-repeat`
      },
      AlarmList: [],
      AlarmNum: 0,
      EquipmentNum: 0,*/
      //业主首页
      eqData: [{
          TypeName: '主机',
          TotalNum: 0,
          OffLineNum: 0,
          AlarmNum: 0
        }, {
          TypeName: '冷冻水泵',
          TotalNum: 0,
          OffLineNum: 0,
          AlarmNum: 0
        }, {
          TypeName: '冷却水泵',
          TotalNum: 0,
          OffLineNum: 0,
          AlarmNum: 0
        }, {
          TypeName: '冷却塔',
          TotalNum: 0,
          OffLineNum: 0,
          AlarmNum: 0
        }, {
          TypeName: '多联机',
          TotalNum: 0,
          OffLineNum: 0,
          AlarmNum: 0
        }, {
          TypeName: '风柜',
          TotalNum: 0,
          OffLineNum: 0,
          AlarmNum: 0
        }
        /*, {
                TypeName: '其他',
                TotalNum: 0,
                OffLineNum: 0,
                AlarmNum: 0
              }*/
      ],
      hostPngSrc,
      hostBgSrc,
      TotalPngSrc,
      OffLinePngSrc,
      AlarmPngSrc,
      // EntitySort: null, //0为业主
      // getEquiStatByAlarmUrl: URL.EQUIPMENTSTATBYALARM, //项目统计信息接口（HttpGet）
    }
  },
  components: {
    topInfo
  },
  computed: {
    imgWrapStyle() {
      return {
        background: `url(${this.hostBgSrc}) 0 0 no-repeat`
      }
    },
    /*routerName() {
      return `${this.urlType}${this.urlName}`
    }*/
  },
  methods: {
    /*linkTo(AlarmStatus) {
      this.$router.push({ name: this.routerName, params: { type: 0, EquipmentTypeId: this.eqData[0].EquipmentTypeId, AlarmStatus: AlarmStatus || '' } })
    },*/
    /*...mapMutations({
      uPDATE_SHOWWHICHTAB: 'UPDATE_SHOWWHICHTAB'
    }),*/
    /*linkTo(type) {
      this.$router.push({ name: this.routerName, params: { type } })
    },*/
    goTo(routerPath, routerParams) {
      let vm = this
      if (routerPath == 'yz_equipments_manage') {
        // vm.uPDATE_SHOWWHICHTAB({ showWhichTab: 1 })
        FUNC.tntool.setTnAuth(routerPath)
        vm.$router.push({ path: `${routerPath}/0`, query: routerParams })
        return
      }
      /*vm.uPDATE_SHOWWHICHTAB({ showWhichTab: 1 })
      FUNC.tntool.setTnAuth(routerPath)
      vm.$router.push({ path: routerPath, query: routerParams })*/
    },
    /*linkToWarn() {
      this.$router.push({ path: this.routerNameWarn})
    },*/

    /*getEntitySort() {
      this.EntitySort = FUNC.storage.get("EntitySort")
      // console.log(this.EntitySort)
    },*/
    getEquiStatByType() {
      let vm = this
      let param = {
        "AccessToken": FUNC.storage.get("AccessToken")
      }
      let url = URL.EQUIPMENTSTATBYTYPE //项目统计信息接口（HttpGet）
      GET(url, param).then(function(res) {
        res = res.data
        if (FUNC.checkCode(res.State, res.Message)) {
          // console.log('EquipmentStatistics:', res)
          for (let index in res.Data) {
            for (let jndex in vm.eqData) {
              if (res.Data[index].TypeName == vm.eqData[jndex].TypeName) {
                vm.eqData[jndex].TotalNum = res.Data[index].TotalNum
                vm.eqData[jndex].OffLineNum = res.Data[index].OffLineNum
                vm.eqData[jndex].AlarmNum = res.Data[index].AlarmNum
              }
            }
          }
        }
      })
    },
    setEquipmentTypeIdOpts() {
      let vm = this
      vm.loading_yz = true
      let url = URL.GETEQUIPMENTTYPE //获取设备类型(下拉框)
      let data = {
        AccessToken: FUNC.storage.get("AccessToken")
      }
      GET(url, data)
        .then(function(response) {
          vm.loading_yz = false
          let res = response.data
          if (FUNC.checkCode(res.State, res.Message)) {
            // res.Data.push({EquipmentTypeId: -1, TypeName: "其他"})
            for (let index in res.Data) {
              for (let jndex in vm.eqData) {
                if (res.Data[index].TypeName == vm.eqData[jndex].TypeName) {
                  vm.eqData[jndex].EquipmentTypeId = res.Data[index].EquipmentTypeId
                }
              }
            }
          }
        })
        .catch(function(error) {
          console.log(error.message)
        });
    },
    /*getEquiStatByAlarm() {
      let vm = this
      let param = {
        "AccessToken": FUNC.storage.get("AccessToken")
      }
      let url = vm.getEquiStatByAlarmUrl
      GET(url, param).then(function(res) {
        res = res.data
        if (FUNC.checkCode(res.State, res.Message)) {
          let AlarmList = res.Data.AlarmList
          if (AlarmList.length != 0) {
            vm.AlarmList = AlarmList
          }
          vm.AlarmNum = res.Data.AlarmNum
          vm.EquipmentNum = res.Data.EquipmentNum
        }
      })
    },*/


    /*getProjectStatistics: function() {
      let vm = this
      let param = {
        "AccessToken": FUNC.storage.get("AccessToken")
      }
      let url = vm.projectStatisticsUrl
      GET(url, param).then(function(res) {
        res = res.data
        // console.log(FUNC.checkCode(res.State, res.Message))
        if (FUNC.checkCode(res.State, res.Message)) {
          // console.log('res:', res)
          let data = res.Data
          vm.AlarmProject = data.AlarmProject;
          vm.OffLineProject = data.OffLineProject;
          vm.OnLineProject = data.OnLineProject;
          vm.TotalProject = data.TotalProject;
        }
      })
    },*/
  },
  mounted: function() {
    // this.getEntitySort()
    // if (this.EntitySort == 0) {
    this.urlType = 'yz'
    this.getEquiStatByType()
    this.setEquipmentTypeIdOpts()
    /*} else {
      this.getEquiStatByAlarm()
      this.urlType = 'wb'
    }*/
  }
}

</script>
