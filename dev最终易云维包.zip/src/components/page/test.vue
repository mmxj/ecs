﻿<style scoped lang='less'>
#index{border: 1px solid #000;}
</style>
<template>
  <div class="el_mainContent">
      <div id="index" ref='index' style='width:100%;height:80vh'></div>
  </div>
</template>
<script>
import jsonData from './data.json'
let echarts = require('echarts/lib/echarts')
require('echarts/lib/chart/scatter')
require('echarts/lib/chart/map')
require('echarts/lib/chart/effectScatter')
export default {
  data: function() {
    return {

    }
  },
  components: {
  },
  computed: {

  },
  methods: {
    init(){
      let el = document.querySelector('#index')
      let myChart = echarts.init(el)
      // myChart.showLoading();
      echarts.registerMap('jiangxi', jsonData);
      // myChart.hideLoading();
      var geoCoordMap = {
          '赣州市':[114.940278,25.85097],
          '吉安市':[114.986373,27.111699],
          '上饶市':[117.971185,28.44442],
          '九江市':[115.992811,29.712034],
          '抚州市':[116.358351,27.98385],
          '宜春市':[114.391136,27.8043],
          '南昌市':[115.892151,28.676493],
          '景德镇市':[117.214664,29.29256],
          '萍乡市':[113.852186,27.622946],
          '鹰潭市':[117.033838,28.238638],
          '新余市':[114.930835,27.810834],
      }
      var data = [
          {name: '赣州市', value: 199},
          {name: '吉安市', value: 39},
          {name: '上饶市', value: 152},
          {name: '九江市', value: 299},
          {name: '抚州市', value: 89},
          {name: '宜春市', value: 52},
          {name: '南昌市', value: 9},
          {name: '景德镇市', value: 352},
          {name: '萍乡市', value: 99},
          {name: '鹰潭市', value: 39},
          {name: '新余市', value: 480},
      ];
      var max = 480, min = 9; // todo 
      var maxSize4Pin = 100, minSize4Pin = 20;

    var convertData = function (data) {
      var res = [];
      for (var i = 0; i < data.length; i++) {
          var geoCoord = geoCoordMap[data[i].name];
          if (geoCoord) {
              res.push({
                  name: data[i].name,
                  value: geoCoord.concat(data[i].value)
              });
          }
      }
      return res;
  };


      let option = {
          title: {
              text: '“绿色金融” - 江西省',
              subtext: '',
              x: 'center',
              textStyle: {
                  color: '#ccc'
              }
          },
          tooltip: {
              trigger: 'item',
              formatter: function (params) {
                if(typeof(params.value)[2] == "undefined"){
                  return params.name + ' : ' + params.value;
                }else{
                  return params.name + ' : ' + params.value[2];
                }
              }
          },
          legend: {
              orient: 'vertical',
              y: 'bottom',
              x: 'right',
              data: ['credit_pm2.5'],
              textStyle: {
                  color: '#fff'
              }
          },
          visualMap: {
              show: false,
              min: 0,
              max: 500,
              left: 'left',
              top: 'bottom',
              text: ['高', '低'], // 文本，默认为数值文本
              calculable: true,
              seriesIndex: [1],
              inRange: {
                  // color: ['#3B5077', '#031525'] // 蓝黑
                  // color: ['#ffc0cb', '#800080'] // 红紫
                  // color: ['#3C3B3F', '#605C3C'] // 黑绿
                  color: ['#0f0c29', '#302b63', '#24243e'] // 黑紫黑
                  // color: ['#23074d', '#cc5333'] // 紫红
                  // color: ['#00467F', '#A5CC82'] // 蓝绿
                  // color: ['#1488CC', '#2B32B2'] // 浅蓝
                  // color: ['#00467F', '#A5CC82'] // 蓝绿
                  // color: ['#00467F', '#A5CC82'] // 蓝绿
                  // color: ['#00467F', '#A5CC82'] // 蓝绿
                  // color: ['#00467F', '#A5CC82'] // 蓝绿

              }
          },
          // toolbox: {
          //     show: true,
          //     orient: 'vertical',
          //     left: 'right',
          //     top: 'center',
          //     feature: {
          //             dataView: {readOnly: false},
          //             restore: {},
          //             saveAsImage: {}
          //             }
          // },
          geo: {
              show: true,
              map: 'jiangxi',
              label: {
                  normal: {
                      show: false
                  },
                  emphasis: {
                      show: false,
                  }
              },
              roam: true,
              itemStyle: {
                  normal: {
                      areaColor: '#031525',
                      borderColor: '#3B5077',
                  },
                  emphasis: {
                      areaColor: '#2B91B7',
                  }
              }
          },
          series : [
        {
              name: 'credit_pm2.5',
              type: 'scatter',
              coordinateSystem: 'geo',
              data: convertData(data),
              symbolSize: function (val) {
                  return val[2] / 10;
              },
              label: {
                  normal: {
                      formatter: '{b}',
                      position: 'right',
                      show: true
                  },
                  emphasis: {
                      show: true
                  }
              },
              itemStyle: {
                  normal: {
                      color: '#05C3F9'
                  }
              }
          },
           {
              type: 'map',
              map: 'jiangxi',
              geoIndex: 0,
              aspectScale: 0.75, //长宽比
              showLegendSymbol: false, // 存在legend时显示
              label: {
                  normal: {
                      show: false
                  },
                  emphasis: {
                      show: false,
                      textStyle: {
                          color: '#fff'
                      }
                  }
              },
              roam: true,
              itemStyle: {
                  normal: {
                      areaColor: '#031525',
                      borderColor: '#3B5077',
                  },
                  emphasis: {
                      areaColor: '#2B91B7'
                  }
              },
              animation: false,
              data: data
          },
          {
              name: '点',
              type: 'scatter',
              coordinateSystem: 'geo',
              symbol: 'pin',
              symbolSize: function (val) {
                  var a = (maxSize4Pin - minSize4Pin) / (max - min);
                  var b = minSize4Pin - a*min;
                  b = maxSize4Pin - a*max;
                  return a*val[2]+b;
              },
              label: {
                  normal: {
                      show: true,
                      textStyle: {
                          color: '#fff',
                          fontSize: 9,
                      }
                  }
              },
              itemStyle: {
                  normal: {
                      color: '#F62157', //标志颜色
                  }
              },
              zlevel: 6,
              data: convertData(data),
          },
          {
              name: 'Top 5',
              type: 'effectScatter',
              coordinateSystem: 'geo',
              data: convertData(data.sort(function (a, b) {
                  return b.value - a.value;
              }).slice(0, 5)),
              symbolSize: function (val) {
                  return val[2] / 10;
              },
              showEffectOn: 'render',
              rippleEffect: {
                  brushType: 'stroke'
              },
              hoverAnimation: true,
              label: {
                  normal: {
                      formatter: '{b}',
                      position: 'right',
                      show: true
                  }
              },
              itemStyle: {
                  normal: {
                      color: '#05C3F9',
                      shadowBlur: 10,
                      shadowColor: '#05C3F9'
                  }
              },
              zlevel: 1
          },
           
      ]
      };
      console.log(option)
      myChart.setOption(option);
    },
  },
  mounted: function() {
    let vm = this
    setTimeout(function () {
      vm.init()
    }, 0)
    
  }
}

</script>
