﻿<style scoped="scoped">
.el_mainContent{
	background: #ccc;
	width:100%;
	height:99%
}
.leftmenu{
	width: 200px;
	height: 100%;
	position: relative;
	background: yellow;
}
.innertest{
	width: 100%;
	position: absolute;
	top: 50px;
	bottom: 100px;
	background: #abc;
	overflow-y: auto;
}

</style>
<template>
  <div class="el_mainContent">
    <div class="leftmenu">
    	<!--<div class="innertest">
    		<div v-for='item in 5'>123</div>
    		<div>123</div>
    	</div>-->
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {

    }
  },
  methods: {},
  mounted: function() {},
  watch: {}
}

</script>
