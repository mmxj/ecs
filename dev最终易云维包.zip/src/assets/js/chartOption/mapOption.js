﻿/*var geoCoordMap = {
  "海南": [110.17, 19.92],
  "河南": [113.700339, 34.751827],
  "河北": [114.54095, 38.058913],
  "湖北": [114.289984, 30.5942],
  "广东": [113.293215, 23.102603],
  "湖南": [113.03042, 28.188898],
  "江西": [115.911671, 28.658012],
  "黑龙江": [126.629804, 45.774197],
  "四川": [104.112035, 30.630737],
  "安徽": [117.321109, 31.850184],
}
var data = [{
    name: '海南',
    value: 99925.73
  },
  {
    name: '河南',
    value: 17737.01
  },
  {
    name: '河北',
    value: 13177.64
  },
  {
    name: '湖北',
    value: 12174.96
  },
  {
    name: '广东',
    value: 8230.15
  },
  {
    name: '湖南',
    value: 8173.05
  },
  {
    name: '江西',
    value: 7423.08
  },
  {
    name: '黑龙江',
    value: 6829.69
  },
  {
    name: '四川',
    value: 6158.43
  },
  {
    name: '安徽',
    value: 5930.80
  },
];
var max = 100000,
  min = 900; // todo 
var maxSize4Pin = 100,
  minSize4Pin = 20;*/

/*var convertData = function(data) {
  var res = [];
  for (var i = 0; i < data.length; i++) {
    var geoCoord = geoCoordMap[data[i].name];
    if (geoCoord) {
      res.push({
        name: data[i].name,
        value: geoCoord.concat(data[i].value)
      });
    }
  }
  return res;
};*/

// console.log(convertData(data));
import defaultPng from 'assets/images/index/default_porject_bg.png'

export default {
  /*title: {
    text: '购买对象所在省份TOP10',
    subtext: '销售面积区间',
    x: 'center',
    textStyle: {
      color: '#ccc'
    }
  },*/
  tooltip: {
    trigger: 'item',
    tirggerOn: 'click',
    borderRadius: 8,
    width: 340,
    backgroundColor: '#0F273E',
    formatter: function(params) {
      // console.log(params)
      //如果不存在params.value.length则表示这个节点没有数据,是一个地区而不是项目
      if (!params.value.length) {
        let res = `<div>${params.name}</div>`
        return res;
      }
      // if (params.value.length < 100) {return '<div>123</div>'}
      let res = '<div class="indexToolTipWrap">'
      res += `<img src='${params.value[5]}' onerror="this.src='${defaultPng}';">`
      res += "<div style='float:left'>"
      res += `<p class='title'>${params.name}</p>`
      res += `<p>负责人：${params.value[2]}</p>`
      res += `<p>维保商：${params.value[3]}</p>`
      res += `<p>地址：${params.value[4]}</p>`
      res += "</div>"
      res += "</div>"
      return res;
    },
  },
  /*legend: {
    orient: 'vertical',
    y: 'bottom',
    x: 'right',
    data: ['sell_area'],
    textStyle: {
      color: '#fff'
    }
  },*/
  legend: {
    top: '15px',
    left: 'center',
    selectedMode: false,
    data: ['正常项目', '提醒项目', '告警项目', '报警项目'],
    textStyle: {
      // fontSize: 12,
      color: '#FEFEFE'
    }
  },
  visualMap: {
    show: false,
    min: 0,
    max: 500,
    left: 'left',
    top: 'bottom',
    text: ['高', '低'], // 文本，默认为数值文本
    calculable: true,
    seriesIndex: [1],
    inRange: {
      // color: ['#3B5077', '#031525'] // 蓝黑
      // color: ['#ffc0cb', '#800080'] // 红紫
      // color: ['#3C3B3F', '#605C3C'] // 黑绿
      // color: ['#0f0c29', '#302b63', '#24243e'] // 黑紫黑
      // color: ['#23074d', '#cc5333'] // 紫红
      // color: ['#00467F', '#A5CC82'] // 蓝绿
      // color: ['#1488CC', '#2B32B2'] // 浅蓝
      // color: ['#00467F', '#A5CC82'] // 蓝绿
      // color: ['#00467F', '#A5CC82'] // 蓝绿
      // color: ['#00467F', '#A5CC82'] // 蓝绿
      // color: ['#00467F', '#A5CC82'] // 蓝绿

    }
  },
  // toolbox: {
  //     show: true,
  //     orient: 'vertical',
  //     left: 'right',
  //     top: 'center',
  //     feature: {
  //             dataView: {readOnly: false},
  //             restore: {},
  //             saveAsImage: {}
  //             }
  // },
  geo: {
    show: true,
    map: 'zhongguo',
    label: {
      normal: {
        show: false
      },
      emphasis: {
        show: false,
      }
    },
    roam: true,
    itemStyle: {
      normal: {
        areaColor: '#031525',
        borderColor: '#3B5077',
      },
      emphasis: {
        areaColor: '#2B91B7',
      }
    }
  },
  series: [{
      name: '正常项目',
      type: 'scatter',
      coordinateSystem: 'geo',
      // data: convertData(data),
      data: [],
      symbolSize: 12,
      label: {
        normal: {
          formatter: '{b}',
          position: 'right',
          show: false
        },
        emphasis: {
          show: false
        }
      },
      itemStyle: {
        normal: {
          color: '#1ABC9C'
        }
      }
    },
    {
      name: '提醒项目',
      type: 'effectScatter',
      coordinateSystem: 'geo',
      symbol: 'pin',
      data: null,
      symbolSize: 50,
      /*symbolSize: function(val) {
        return val[2] / 10;
      },*/
      showEffectOn: 'emphasis',
      rippleEffect: {
        brushType: 'stroke'
      },
      hoverAnimation: true,
      itemStyle: {
        normal: {
          color: '#3798D4',
          shadowBlur: 10,
          shadowColor: '#333'
        }
      },
      zlevel: 1
    },
    {
      name: '告警项目',
      type: 'effectScatter',
      coordinateSystem: 'geo',
      symbol: 'pin',
      data: null,
      symbolSize: 50,
      showEffectOn: 'emphasis',
      rippleEffect: {
        brushType: 'stroke'
      },
      hoverAnimation: true,
      itemStyle: {
        normal: {
          color: '#F1C40F',
          shadowBlur: 10,
          shadowColor: '#333'
        }
      },
      zlevel: 1
    },
    {
      name: '报警项目',
      type: 'effectScatter',
      coordinateSystem: 'geo',
      symbol: 'pin',
      data: null,
      symbolSize: 50,
      showEffectOn: 'emphasis',
      rippleEffect: {
        brushType: 'stroke'
      },
      hoverAnimation: true,
      itemStyle: {
        normal: {
          color: '#E74C3C',
          shadowBlur: 10,
          shadowColor: '#333'
        }
      },
      zlevel: 1
    },
    {
      type: 'map',
      map: 'zhongguo',
      geoIndex: 0,
      aspectScale: 0.75, //长宽比
      showLegendSymbol: false, // 存在legend时显示
      label: {
        normal: {
          show: false
        },
        emphasis: {
          show: false,
          textStyle: {
            color: '#fff'
          }
        }
      },
      roam: true,
      itemStyle: {
        normal: {
          areaColor: '#031525',
          borderColor: '#3B5077',
        },
        emphasis: {
          areaColor: '#2B91B7'
        }
      },
      animation: false,
      // data: data
    },
    /*{
      name: '点',
      type: 'scatter',
      coordinateSystem: 'geo',
      symbol: 'pin',
      symbolSize: function(val) {
        var a = (maxSize4Pin - minSize4Pin) / (max - min);
        var b = minSize4Pin - a * min;
        b = maxSize4Pin - a * max;
        return a * val[2] + b;
      },
      label: {
        normal: {
          show: true,
          textStyle: {
            color: '#fff',
            fontSize: 9,
          }
        }
      },
      itemStyle: {
        normal: {
          color: '#F62157', //标志颜色
        }
      },
      zlevel: 6,
      data: convertData(data),
    },
    {
      name: 'Top 5',
      type: 'effectScatter',
      coordinateSystem: 'geo',
      data: convertData(data.sort(function(a, b) {
        return b.value - a.value;
      }).slice(0, 5)),
      symbolSize: function(val) {
        return val[2] / 5000;
      },
      showEffectOn: 'render',
      rippleEffect: {
        brushType: 'stroke'
      },
      hoverAnimation: true,
      label: {
        normal: {
          formatter: '{b}',
          position: 'right',
          show: false
        }
      },
      itemStyle: {
        normal: {
          color: '#05C3F9',
          shadowBlur: 10,
          shadowColor: '#05C3F9'
        }
      },
      zlevel: 1
    },*/

  ]

}
