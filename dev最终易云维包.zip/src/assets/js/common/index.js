﻿import Func from './commonFunc'
import Const from './commonConst'
export {Func,Const}